Members:
    - Pradhyum Krishnan (pk555)
    - Gaurav Patel (gvp23)

# Note:
Please pass in all the optional arguments before the main arguments.

# Strategy:
We started with using our previous assignments code to read in the words. After we made all of the neccessary structs such as file repositories, queues, linked lists, etc, we began to think of test cases and tried to create our algorithms based on the them. For example, we thought handiling uppercass letters, puncuations, and hypens. After we implemented storing our folder and files in our queue structs using directory/files threads, we started to implement the analysis thread. To start off, we only did single threading; and, after checking all of the cases such as putting in files with the invalid suffixs, periods, specific suffix, putting files before directors and vice-versa, passing in only 1 file, passing same files, and passing in a combination of files and folders. After this, we used a combination of techniques to attemp multithreading throughout the entire process.